<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Contractor_on_project extends Model
{
    use HasFactory;
    protected $table = 'contractor_on_project';
}
