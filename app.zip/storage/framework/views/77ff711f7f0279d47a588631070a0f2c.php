<table class="table">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Project Name</th>
            <th scope="col">Building Name</th>
            <th scope="col">Owner</th>
            <th scope="col">Year</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr ondblclick="selectProject('<?php echo e($project->id); ?>')">
                <td><?php echo e($project->id_project); ?></td>
                <td><?php echo e($project->project_name); ?></td>
                <td><?php echo e($project->building_name); ?></td>
                <td><?php echo e($project->project_owner); ?></td>
                <td><?php echo e($project->year); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\admin\Documents\web\RAB SIPIL\app_1\resources\views/project/include/table_list_project.blade.php ENDPATH**/ ?>