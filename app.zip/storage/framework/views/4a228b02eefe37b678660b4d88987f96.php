<table class="table">
    <thead>
      <tr>
        <th scope="col">Job</th>
        <th scope="col">Category</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr ondblclick="getJob('<?php echo e($job->id); ?>')">
                <td><?php echo e($job->job_name); ?></td>
                <td><?php echo e($job->job_category->job_category); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\admin\Documents\web\RAB SIPIL\app_1\resources\views/admin/include/table_search_job.blade.php ENDPATH**/ ?>