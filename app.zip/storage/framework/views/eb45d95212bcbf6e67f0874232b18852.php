<table>
    <thead>
        <tr style="font-weight: bold; color: red">
            <th style="background-color: yellow;"><b>Ketagori AHS</b></th>
            <th style="background-color: yellow;"><b>Pekerjaan</b></th>
            <th style="background-color: yellow;"><b>Keterangan</b></th>
            <th style="background-color: yellow;"><b>Volume</b></th>
            <th style="background-color: yellow;"><b>Satuan</b></th>
            <th style="background-color: yellow;"><b>Material Kategory</b></th>
            <th style="background-color: yellow;"><b>Material</b></th>
            <th style="background-color: yellow;"><b>Jumlah Material</b></th>
            <th style="background-color: yellow;"><b>Satuan</b></th>
            <th style="background-color: yellow;"><b>Harga satuan</b></th>
            <th style="background-color: yellow;"><b>Total</b></th>
        </tr>
    </thead>
    <tbody>
        <?php
            $total = 0;
        ?>
        <?php $__currentLoopData = $data_job_on_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job_on_project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $first_line_1 = true;
                $grand_total = 0;
            ?>
            <?php $__currentLoopData = $job_on_project['material']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $price_per_category = 0;
                    $first_line = true;
                ?>
                <?php $__currentLoopData = $material['list']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($first_line_1 == true): ?>
                            <td><?php echo e($job_on_project['job_category']); ?></td>
                            <td><?php echo e($job_on_project['job']); ?></td>
                            <td><?php echo e($job_on_project['desc']); ?></td>
                            <td><?php echo e($job_on_project['qty']); ?></td>
                            <td><?php echo e($job_on_project['unit']); ?></td>
                            <?php
                                $first_line_1 = false;
                            ?>
                        <?php else: ?>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        <?php endif; ?>
                        
                        
                        <?php if($first_line == true): ?>
                            <td rowspan="<?php echo e(count($material['list'])); ?>"><?php echo e($material['material_category']); ?></td>
                            <?php
                                $first_line = false;
                            ?>
                        <?php endif; ?>
                        <td><?php echo e($list->material_name); ?></td>
                        <td><?php echo e($list->qty * $job_on_project['qty']); ?></td>
                        <td><?php echo e($list->unit); ?></td>
                        <td align="right"><?php echo e(number_format($list->price,0,',',',')); ?></td>
                        <td align="right"><?php echo e(number_format($list->qty * $job_on_project['qty'] * $list->price,0,',',',')); ?></td>
                    </tr>
                    <?php
                        $price_per_category += $list->qty * $job_on_project['qty'] * $list->price;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($price_per_category != 0): ?>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th> </th>
                        <th></th>
                        <th></th>
                        <th colspan="2"><b>Total</b></th>
                        <th align="right"><b><?php echo e(number_format($price_per_category,0,',',',')); ?></b></th>
                        
                    </tr>
                        <?php
                            $grand_total += $price_per_category;
                        ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th> </th>
                <th></th>
                <th></th>
                <th colspan="2"><b>Grand Total</b></th>
                <th align="right"><b><?php echo e(number_format($grand_total,0,',',',')); ?></b></th>
                
            </tr>
            <?php
                $total += $grand_total;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th></th>
            <th> </th>
            <th></th>
            <th></th>
            <th colspan="2"><b>TOTAL</b></th>
            <th align="right"><b><?php echo e(number_format($total,0,',',',')); ?></b></th>
            
        </tr>
    </tbody>
</table>
<?php /**PATH C:\Users\admin\Documents\web\RAB SIPIL\app_1\resources\views/exports/recap_material_and_price.blade.php ENDPATH**/ ?>