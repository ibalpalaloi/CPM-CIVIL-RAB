<table class="table">
    <thead>
        <tr>
            <th scope="col">contractor</th>
            <th scope="col">contact</th>
            <th scope="col">desc</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $contractors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contractor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr ondblclick="selectContractor('<?php echo e($contractor->id); ?>')">
            <td><?php echo e($contractor->contractor_name); ?></td>
            <td><?php echo e($contractor->contact); ?></td>
            <td><?php echo e($contractor->desc); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\admin\Documents\web\RAB SIPIL\app_1\resources\views/admin/contractor/include/table_search_contractor.blade.php ENDPATH**/ ?>