<table class="table">
    <thead>
        <tr>
            <th scope="col">Kategori</th>
            <th scope="col">Desc</th>
            <th scope="col">AHS</th>
            <th scope="col">Ket</th>
            <th scope="col">Volume</th>
            <th scope="col">Satuan</th>
            <th scope="col">price</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data_job_on_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="tr_job_on_project_<?php echo e($data['id']); ?>">
                <td><?php echo e($data['job_category']); ?></td>
                <td><?php echo e($data['desc']); ?></td>
                <td><?php echo e($data['job_name']); ?></td>
                <td><?php echo e($data['job_desc']); ?></td>
                <td><?php echo e($data['qty']); ?></td>
                <td><?php echo e($data['unit']); ?></td>
                <td><?php echo e(number_format($data['price'],0,',','.')); ?></td>
                <th>
                    <?php if($data['status'] == 'unposted'): ?>
                        <button onclick="delete_job_on_project('<?php echo e($data['id']); ?>')" class="btn btn-danger btn-sm"><i class="ti ti-trash"></i></button>
                        
                    <?php else: ?>
                        
                    <?php endif; ?>
                </th>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\admin\Documents\web\RAB SIPIL\app_1\resources\views/project/include/table_d_job_on_project.blade.php ENDPATH**/ ?>