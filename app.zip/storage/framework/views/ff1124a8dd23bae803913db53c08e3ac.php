<table>
    <tr>
        <td width="35">Nama Proyek</td>
        <td align="left" ><b><?php echo e($project->project_name); ?></b></td>
    </tr>
    <tr>
        <td>Nama Bangunan</td>
        <td align="left"><b><?php echo e($project->building_name); ?></b></td>
    </tr>
    <tr>
        <td>Pemilik Proyek</td>
        <td align="left"><b><?php echo e($project->project_owner); ?></b></td>
    </tr>
    <tr>
        <td>Tahun</td>
        <td align="left"><b><?php echo e($project->year); ?></b></td>
    </tr>
</table>

<table>
    <thead>
        <tr>
            <th style="background-color: yellow;">Material</th>
            <th style="background-color: yellow;">Jumlah Material</th>
            <th style="background-color: yellow;">Satuan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $list_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($data['material_name']); ?></td>
                <td><?php echo e($data['qty']); ?></td>
                <td><?php echo e($data['unit']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\admin\Documents\web\RAB SIPIL\app_1\resources\views/exports/recap_material.blade.php ENDPATH**/ ?>