<table>
    <tr>
        <td></td>
        <td width="35">NAMA PROJECT</td>
        <td align="left" width="35"><b><?php echo e($project_summary->project_name); ?></b></td>
    </tr>
    <tr>
        <td></td>
        <td width="35">NAMA BANGUNAN</td>
        <td align="left"><b><?php echo e($project_summary->building_name); ?></b></td>
    </tr>
    <tr>
        <td></td>
        <td width="35">PEMILIK PROYEK</td>
        <td align="left"><b><?php echo e($project_summary->project_owner); ?></b></td>
    </tr>
    <tr>
        <td></td>
        <td width="35">TAHUN</td>
        <td align="left"><b><?php echo e($project_summary->year); ?></b></td>
    </tr>
</table>

<table>
    <thead>
        <tr style="font-weight: bold; color: red">
            <th style="background-color: yellow;"><b>No</b></th>
            <th style="background-color: yellow;"><b>Kategori</b></th>
            <th style="background-color: yellow;"><b>Deskripsi</b></th>
            <th style="background-color: yellow;"><b>AHS</b></th>
            <th style="background-color: yellow;"><b>Keterangan</b></th>
            <th style="background-color: yellow;"><b>Volume</b></th>
            <th style="background-color: yellow;"><b>Unit</b></th>
            <th style="background-color: yellow;"><b>Harga Satuan Upah</b></th>
            <th style="background-color: yellow;"><b>Harga Satuan Material</b></th>
            <th style="background-color: yellow;"><b>Harga Satuan Alat</b></th>
            <th style="background-color: yellow;"><b>Harga Satuan</b></th>
            <th style="background-color: yellow;"><b>Total</b></th>
        </tr>
    </thead>
    <tbody>
        <?php
            $total_price = 0;
            $no=1;
        ?>
        <?php $__currentLoopData = $data_job_on_project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data['job_category']); ?></td>
                <td><?php echo e($data['desc_job_project']); ?></td>
                <td><?php echo e($data['job']); ?></td>
                <td><?php echo e($data['desc_job']); ?></td>
                <td><?php echo e($data['qty']); ?></td>
                <td><?php echo e($data['unit']); ?></td>
                <td><?php echo e(number_format($data['Upah'],0,',',',')); ?></td>
                <td><?php echo e(number_format($data['Material'],0,',',',')); ?></td>
                <td><?php echo e(number_format($data['Alat'],0,',',',')); ?></td>
                <td><?php echo e(number_format($data['Alat']+$data['Material']+$data['Upah'],0,',',',')); ?></td>
                <td><?php echo e(number_format(($data['Alat']+$data['Material']+$data['Upah']) * $data['qty'],0,',',',')); ?></td>
            </tr>
            <?php
                $total_price += ($data['Alat']+$data['Material']+$data['Upah']) * $data['qty'];
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td><?php echo e(number_format($total_price,0,',',',')); ?></td>
        </tr>
    </tbody>
</table>
<?php /**PATH C:\Users\admin\Documents\web\RAB SIPIL\app_1\resources\views/exports/recap_rab.blade.php ENDPATH**/ ?>