<?php $__currentLoopData = $dataMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataMaterial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <table class="table table-bordered">
        <thead>
            <tr>
                <td style="background-color: #90B9F7" colspan="6"><b><?php echo e($dataMaterial['materialCategory']); ?></b></td>
            </tr>
            <tr style="font-weight: bold">
                <th style=""></th>
                <th></th>
                <th>index</th>
                <th>Satun</th>
                <th>Harga</th>
                <th>Total</th>
            </tr>

        </thead>
        <tbody>
            <?php
                $total = 0;
            ?>
            <?php $__currentLoopData = $dataMaterial['listMaterial']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr style="font-size: 12px;">
                    <td style="width: 10%">
                        <button onclick="editItemOfJob('<?php echo e($list->id); ?>')" class="btn btn-sm btn-warning">
                            <i class="ti ti-pencil"></i>
                        </button>
                        <button onclick="deleteItemOfJob('<?php echo e($list->id); ?>')" class="btn btn-sm btn-danger">
                            <i class="ti ti-trash"></i>
                        </button>
                    </td>
                    <td><?php echo e($list->material_name); ?></td>
                    <td><?php echo e($list->qty); ?></td>
                    <td><?php echo e($list->unit); ?></td>
                    <td><?php echo e(number_format($list->price,0,',','.')); ?></td>
                    <td><?php echo e(number_format($list->qty* $list->price,0,',','.')); ?></td>
                </tr>
                <?php
                    $total += $list->qty * $list->price;
                ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr style="font-size: 12px">
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>Rp. <?php echo e(number_format($total,0,',','.')); ?></td>
            </tr>
        </tbody>
    </table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\admin\Documents\web\RAB SIPIL\app_1\resources\views/admin/include/table_item_of_job.blade.php ENDPATH**/ ?>